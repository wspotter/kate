"""
FastAPI Web Server for Kate LLM Client
"""
import asyncio
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

import uvicorn
from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

from app.core.config import get_settings
from app.database.manager import DatabaseManager
from app.services.rag_integration_service import RAGIntegrationService
from app.services.voice_chat_service import VoiceChatService


class ChatMessage(BaseModel):
    content: str
    role: str = "user"


class ChatResponse(BaseModel):
    content: str
    role: str = "assistant"


class WebServer:
    def __init__(self):
        self.app = FastAPI(title="Kate LLM Client", version="1.0.0")
        self.settings = get_settings()
        
        # Initialize services
        self.db_manager = DatabaseManager()
        self.rag_service = RAGIntegrationService()
        self.voice_service = VoiceChatService()
        
        # Setup templates and static files
        self.templates = Jinja2Templates(directory="app/templates")
        
        # Create static and templates directories
        Path("app/static").mkdir(exist_ok=True)
        Path("app/templates").mkdir(exist_ok=True)
        
        self.app.mount("/static", StaticFiles(directory="app/static"), name="static")
        
        # Active WebSocket connections
        self.active_connections: List[WebSocket] = []
        
        self._setup_routes()
    
    def _setup_routes(self):
        """Setup all web routes"""
        
        @self.app.get("/", response_class=HTMLResponse)
        async def home(request: Request):
            return self.templates.TemplateResponse("index.html", {"request": request})
        
        @self.app.get("/chat", response_class=HTMLResponse)
        async def chat_page(request: Request):
            return self.templates.TemplateResponse("chat.html", {"request": request})
        
        @self.app.post("/api/chat")
        async def chat_endpoint(message: ChatMessage) -> ChatResponse:
            """Handle chat messages via REST API"""
            try:
                # Use RAG service for enhanced responses
                response = await self.rag_service.process_query(
                    query=message.content,
                    conversation_id="web_session",
                    include_context=True
                )
                
                return ChatResponse(
                    content=response.get("answer", "I'm sorry, I couldn't process that request."),
                    role="assistant"
                )
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Chat processing error: {str(e)}")
        
        @self.app.get("/api/health")
        async def health_check():
            """Health check endpoint"""
            return {"status": "healthy", "services": {
                "database": await self._check_database(),
                "rag": await self._check_rag_service(),
                "voice": await self._check_voice_service()
            }}
        
        @self.app.websocket("/ws/chat")
        async def websocket_chat(websocket: WebSocket):
            """WebSocket endpoint for real-time chat"""
            await websocket.accept()
            self.active_connections.append(websocket)
            
            try:
                while True:
                    # Receive message from client
                    data = await websocket.receive_text()
                    
                    # Process with RAG service
                    response = await self.rag_service.process_query(
                        query=data,
                        conversation_id="websocket_session",
                        include_context=True
                    )
                    
                    # Send response back
                    await websocket.send_text(response.get("answer", "Error processing request"))
                    
            except WebSocketDisconnect:
                self.active_connections.remove(websocket)
        
        @self.app.get("/api/settings")
        async def get_settings():
            """Get current Kate settings"""
            return {
                "voice_enabled": True,
                "rag_enabled": True,
                "models_available": ["gpt-3.5-turbo", "claude-3", "local-llama"]
            }
        
        @self.app.post("/api/voice/process")
        async def process_voice(request: Request):
            """Process voice input (placeholder)"""
            return {"message": "Voice processing not yet implemented in web interface"}
    
    async def _check_database(self) -> bool:
        """Check database connectivity"""
        try:
            await self.db_manager.initialize()
            return True
        except:
            return False
    
    async def _check_rag_service(self) -> bool:
        """Check RAG service availability"""
        try:
            # Simple test query
            await self.rag_service.process_query("test", "health_check")
            return True
        except:
            return False
    
    async def _check_voice_service(self) -> bool:
        """Check voice service availability"""
        try:
            # Just check if service exists
            return self.voice_service is not None
        except:
            return False
    
    async def startup(self):
        """Initialize services on startup"""
        await self.db_manager.initialize()
        # Initialize other services as needed
    
    async def shutdown(self):
        """Cleanup on shutdown"""
